<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class cpn_suivi extends Model
{
    //
}
