<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class RapportAlerteUser extends Model
{
    //
}
