<?php

namespace App\Http\Controllers;

use App\EntretienPair;
use Illuminate\Support\Facades\DB;

class EntretienParticipantControllerSuite extends Controller
{
   public function __invoke()
    {
       $page = 'entretien-participant-suite';

       return view('Admin.entretien_participant_suite.index', compact('page'));
    }
   // public function index(){
     //   $query= DB::table('Donnees_PE')->get();
        //return dd($query);
       // return view('Admin.entretien_participant_suite.index',);
    //}
}
