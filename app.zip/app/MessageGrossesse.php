<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class MessageGrossesse extends Model
{
    //
}
