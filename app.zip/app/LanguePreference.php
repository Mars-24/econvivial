<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class LanguePreference extends Model
{
    //
}
