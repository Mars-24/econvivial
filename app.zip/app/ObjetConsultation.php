<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class ObjetConsultation extends Model
{
    //
}
