<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class QuizQuestionDetail extends Model
{
    //
}
