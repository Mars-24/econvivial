<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class MessagePvvihUser extends Model
{
    //
}
