<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class AffectationPE extends Model
{
    //
}
