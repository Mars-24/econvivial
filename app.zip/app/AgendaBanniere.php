<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class AgendaBanniere extends Model
{
    //
}
