<?php

namespace App;

use Illuminate\Database\Eloquent\Relations\Pivot;

class Covid19CityCase extends Pivot
{
    // 
}