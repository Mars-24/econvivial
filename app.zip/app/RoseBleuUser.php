<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class RoseBleuUser extends Model
{
    //
}
